import { IsNumber, IsString, IsDate, IsOptional } from 'class-validator';

export class LeadDto {
  @IsNumber()
  lid: number;

  @IsOptional()
  @IsNumber()
  luid: number | null;

  @IsOptional()
  @IsNumber()
  lcid: number | null;

  @IsOptional()
  @IsDate()
  ladate: Date | null;

  @IsOptional()
  @IsString()
  lstatus: string | null;

  @IsOptional()
  @IsString()
  lstatus2: string | null;

  @IsOptional()
  @IsString()
  ltype: string | null;

  @IsOptional()
  @IsString()
  lservice: string | null;

  @IsOptional()
  @IsNumber()
  lstatusuid: number | null;

  @IsOptional()
  @IsString()
  lstatusreason: string | null;

  @IsOptional()
  @IsDate()
  lstatusdate: Date | null;

  @IsOptional()
  @IsDate()
  llastcontact: Date | null;

  @IsOptional()
  @IsNumber()
  llastcontactuid: number | null;

  @IsOptional()
  @IsString()
  lsource: string | null;

  @IsOptional()
  @IsString()
  lcomp: string | null;

  @IsOptional()
  @IsString()
  lcontact: string | null;

  @IsOptional()
  @IsString()
  ltitle: string | null;

  @IsOptional()
  @IsString()
  llname: string | null;

  @IsOptional()
  @IsString()
  laddr1: string | null;

  @IsOptional()
  @IsString()
  laddr2: string | null;

  @IsOptional()
  @IsString()
  lcity: string | null;

  @IsOptional()
  @IsString()
  lst: string | null;

  @IsOptional()
  @IsNumber()
  lzip: number | null;

  @IsOptional()
  @IsString()
  llatlon: string | null;

  @IsOptional()
  @IsString()
  lphone: string | null;

  @IsOptional()
  @IsString()
  lext: string | null;

  @IsOptional()
  @IsString()
  laltphone: string | null;

  @IsOptional()
  @IsString()
  laltext: string | null;

  @IsOptional()
  @IsString()
  lemail: string | null;

  @IsOptional()
  @IsNumber()
  llotid: bigint | null;

  @IsOptional()
  @IsString()
  lnotes: string | null;

  @IsOptional()
  @IsString()
  lfax: string | null;

  @IsOptional()
  @IsString()
  lcontact2: string | null;

  @IsOptional()
  @IsString()
  ltitle2: string | null;

  @IsOptional()
  @IsNumber()
  lphone2: bigint | null;

  @IsOptional()
  @IsString()
  lext2: string | null;

  @IsOptional()
  @IsString()
  lemail2: string | null;

  @IsOptional()
  @IsString()
  lemail2cc: string | null;

  @IsOptional()
  @IsString()
  lbtype: string | null;

  @IsOptional()
  @IsNumber()
  lbfloors: number | null;

  @IsOptional()
  @IsString()
  lbroofmat: string | null;

  @IsOptional()
  @IsString()
  lbhatch: string | null;

  @IsOptional()
  @IsNumber()
  lbheight: number | null;

  @IsOptional()
  @IsDate()
  linspection: Date | null;

  @IsOptional()
  @IsDate()
  linspectioncomp: Date | null;

  @IsOptional()
  @IsString()
  linspectionnotes: string | null;

  @IsOptional()
  @IsString()
  llocnotes: string | null;

  @IsOptional()
  @IsNumber()
  lapp: number | null;

  @IsOptional()
  @IsString()
  linvpays: string | null;

  @IsOptional()
  @IsString()
  linsuranceco: string | null;

  @IsOptional()
  @IsString()
  lclaimnum: string | null;

  @IsOptional()
  @IsNumber()
  lsimpleinspections: string | null;
}
