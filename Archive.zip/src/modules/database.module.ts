// ormconfig.ts or any file you use for configuration
import { DataSource } from 'typeorm';
import dbConfig from '../database/db.config';

export const AppDataSource = new DataSource(dbConfig);
x;
