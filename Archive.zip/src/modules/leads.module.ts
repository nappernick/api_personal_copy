import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LeadsController } from '../controllers/leads.controller';
import { Lead } from '../entities/lead.entity';
import { LeadsService } from '../services/leads.service';
import { UsersService } from '../services/users.service';
import { User } from '../entities/user.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Lead, User])],
  providers: [LeadsService, UsersService],
  controllers: [LeadsController],
  exports: [TypeOrmModule],
})
export class LeadsModule {}
