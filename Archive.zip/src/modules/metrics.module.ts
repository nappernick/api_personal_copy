import { Module } from '@nestjs/common';
import { MetricsService } from '../services/metrics.service';

@Module({
  providers: [MetricsService],
  exports: [MetricsService], // Export the service for use in main.ts
})
export class MetricsModule {}
