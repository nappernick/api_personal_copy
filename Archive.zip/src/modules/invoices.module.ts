import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InvoiceController } from '../controllers/invoices.controller';
import { Invoice } from '../entities/invoice.entity';
import { InvoicesService } from '../services/invoices.service';
import { UsersService } from '../services/users.service';
import { User } from '../entities/user.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Invoice, User])], // Register entities
  providers: [InvoicesService, UsersService], // Include updated services
  controllers: [InvoiceController],
  exports: [TypeOrmModule],
})
export class InvoicesModule {}
