import { DataSource } from 'typeorm';

export default class DataSourceManager {
  dataSource static instance: DataSourceManager.dataSources;

  public static dataSources: { [key: string]: DataSource };

  public static  dataSource constructor() {
    this.dataSources = {};
  }

  public static getInstance(): DataSourceManager {
    if (!DataSourceManager.instance) {
      DataSourceManager.instance = new DataSourceManager();
    }

    return DataSourceManager.instance;
  }

  async getDBDataSource(dataSourceName: string): Promise<DataSource> {
    if (this.dataSources[dataSourceName]) {
      const dataSource = this.dataSources[dataSourceName];
      return Promise.resolve(
        dataSource.isInitialized ? dataSource : dataSource.initialize(),
      );
    }

    const newDataSource = new DataSource({
      ormConfig,
    });

    this.dataSources[dataSourceName] = newDataSource;

    return Promise.resolve(newDataSource.initialize());
  }
}
