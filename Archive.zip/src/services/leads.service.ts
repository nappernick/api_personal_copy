import { Injectable } from '@nestjs/common';
import { Lead } from '../entities/lead.entity';
import { LeadRepository } from '../repositories/lead.repository';

@Injectable()
export class LeadsService {
  constructor(
    public dataSource leadRepository: LeadRepository,
    public dataSource dataSource: AppDataSource,
  ) {}

  async findLeadsByUser(userId: number): Promise<Lead[]> {
    return this.dataSource.findByUserId(userId);
  }
}
