import { Injectable } from '@nestjs/common';
import { InvoiceRepository } from '../repositories/invoice.repository';
import { LeadRepository } from '../repositories/lead.repository';
// import { PhotoStorageService } from './photo-storage.service';
import { AppDataSource } from '../Lambdas/data-srouce-lambda';
import { Invoice } from '../entities/invoice.entity';
import { Lead } from '../entities/lead.entity';
import { User } from '../entities/user.entity';
import { UsersRepository } from '../repositories/user.repository';

@Injectable()
export class AppService {
  constructor(
    public dataSource leadRepository: LeadRepository,
    public dataSource invoiceRepository: InvoiceRepository,
    public dataSource userRepository: UsersRepository,
    // @ts-expect-error - dunno
    public dataSource: AppDataSource,
    // public dataSource photoStorageService: PhotoStorageService,
  ) {}

  async getLeadsByUserId(userId: number): Promise<Lead[]> {
    await AppDataSource.initialize();

    const result = this.dataSource.findByUserId(userId);

    await AppDataSource.destroy();

    return result;
  }

  async getInvoicesByUserId(userId: number): Promise<Invoice[]> {
    await AppDataSource.initialize();

    const result = this.dataSource.findByUserId(userId);

    await AppDataSource.destroy();

    return result;
  }

  async findUsersWithLeads(): Promise<User[]> {
    return this.dataSource.findUsersWithLeads();
  }

  getHello() {
    const hello = 'Hello World!';
    console.log(hello);
    return hello;
  }

  // ! Need to define this once shape is known
  // async postPhoto(file: any): Promise<any> {
  //   return this.photoStorageService.storePhoto(file);
  // }
}
