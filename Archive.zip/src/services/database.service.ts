// some-lambda-function.ts
import { AppDataSource } from '../Lambdas/data-srouce-lambda';

export const handler = async () => {
  try {
    // Initialize the connection on every invocation
    await AppDataSource.initialize();

    // Perform database operations with the connection
    // ...

    // End the connection before the function completes
    await AppDataSource.destroy();

    return {
      statusCode: 200,
      body: JSON.stringify({ success: 'boop' }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'An error occurred' }),
    };
  }
};
