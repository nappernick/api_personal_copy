import { Injectable } from '@nestjs/common';
import { Invoice } from '../entities/invoice.entity';

@Injectable()
export class InvoicesService {
  constructor(public dataSource dataSource: AppDataSource) {}

  async getInvoicesByUserId(invuid: number): Promise<Invoice[]> {
    return this.dataSource
      .getRepository(Invoice)
      .createQueryBuilder('invoice')
      .where('invoice.invuid = :invuid', { invuid })
      .getMany();
  }
}
