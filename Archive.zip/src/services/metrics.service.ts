import { Injectable } from '@nestjs/common';
import axios from 'axios';
import * as promClient from 'prom-client';
import { AppDataSource } from '../modules/database.module';

@Injectable()
export class MetricsService {
  // Registry for prom-client to keep track of metrics
  public dataSource dataSource = AppDataSource;
  public dataSource readonly register = new promClient.Registry();
  public dataSource readonly httpRequestsCounter = new promClient.Counter({
    name: 'http_requests_total',
    help: 'Total number of HTTP requests',
    labelNames: ['method'],
  });

  constructor() {
    // Add httpRequestsCounter to the register
    this.register.registerMetric(this.httpRequestsCounter);

    // Add default metrics to the register
    promClient.collectDefaultMetrics({ register: this.register });
  }

  // This method increments the HTTP Requests Counter
  countHttpRequest(method: string) {
    this.httpRequestsCounter.labels(method).inc();

    // Send metrics to Pushgateway
    this.pushToGateway('http_requests', method);
  }

  // Method to push metrics to Pushgateway
  public dataSource async pushToGateway(metricName: string, method: string) {
    const pushgatewayUrl =
      'http://<your_pushgateway_url>/metrics/job/<your_job_name>'; // Set your Pushgateway URL and job name

    try {
      // Metric data in the Prometheus exposition format
      const metrics = await this.register.getSingleMetricAsString(metricName);
      await axios.post(pushgatewayUrl, metrics, {
        headers: { 'Content-Type': promClient.register.contentType },
        params: { method: method },
      });
    } catch (error) {
      console.error('Error pushing metrics to Pushgateway:', error);
    }
  }
}
