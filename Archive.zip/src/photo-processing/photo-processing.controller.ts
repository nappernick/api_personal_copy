import { Controller } from '@nestjs/common';

@Controller('photo-processing')
export class PhotoProcessingController {}
