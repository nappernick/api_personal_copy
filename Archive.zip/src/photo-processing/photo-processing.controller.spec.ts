import { Test, TestingModule } from '@nestjs/testing';
import { PhotoProcessingController } from './photo-processing.controller';

describe('PhotoProcessingController', () => {
  let controller: PhotoProcessingController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PhotoProcessingController],
    }).compile();

    controller = module.get<PhotoProcessingController>(
      PhotoProcessingController,
    );
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
