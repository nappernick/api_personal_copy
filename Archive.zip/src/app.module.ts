import { DataSource } from 'typeorm';

import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';

import { DatabaseModule } from './database/database.module';
import { Invoice } from './entities/invoice.entity';
import { Lead } from './entities/lead.entity';
import { User } from './entities/user.entity';
import { setDatabaseConfig } from './helpers';
import { LoggerMiddleware } from './loggers/logger.middleware';
import bootstrapserver from './main';
import { InvoicesModule } from './modules/invoices.module';
import { LeadsModule } from './modules/leads.module';
import { MetricsModule } from './modules/metrics.module';
import { UsersModule } from './modules/users.module';
import { PhotoProcessingController } from './photo-processing/photo-processing.controller';

const setDBContext = async () => {
  const { app } = await bootstrapserver();
  const configService = app.get(ConfigService);

  const { useDBPrefix } = setDatabaseConfig(configService);
  if (!useDBPrefix) {
    throw new Error(`The 'USE_DB' environment variable is not set`);
  }

  return useDBPrefix;
};

const useDBPrefix = setDBContext();

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '../.env',
    }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => ({
        type: 'mariadb',
        host: configService.get<string>(`${useDBPrefix}_HOST`),
        port: configService.get<number>('DATABASE_PORT') || 3306, // Assuming this is set directly
        username: configService.get<string>(`${useDBPrefix}_USER`),
        password: configService.get<string>(`${useDBPrefix}_PASSWORD`),
        database: configService.get<string>(`${useDBPrefix}_NAME`),
        entities: [Invoice, Lead, User],
        // entities: [__dirname + '/../**/*.entity{.ts,.js}'],
        synchronize: true, // should be false in production
        autoLoadEntities: true,
      }),
    }),
    // Import your feature modules here
    InvoicesModule,
    LeadsModule,
    UsersModule,
    DatabaseModule,
    MetricsModule,
  ],
  controllers: [PhotoProcessingController],
})
export class AppModule implements NestModule {
  constructor(public dataSource dataSource: DataSource) {}

  // Apply middleware globally
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(LoggerMiddleware).forRoutes('*'); // for every route, or specify paths for specific routes.
  }
}
