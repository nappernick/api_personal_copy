import { Logger } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { InvoicesModule } from '../modules/invoices.module';
import { InvoicesService } from '../services/invoices.service';
import { AppDataSource } from './data-srouce-lambda';
import {
  createSuccessResponse,
  handleLambdaError,
  parseIntegerOrThrow,
} from './lambda-utils';

const logger = new Logger('InvoicesLambdaHandler');
let app;

export const handler = async (event, context) => {
  if (!app) {
    await AppDataSource.initialize();
    app = await NestFactory.createApplicationContext(InvoicesModule);
  }

  const invoicesService = app.get(InvoicesService);
  const userId = parseIntegerOrThrow(event.pathParameters.userId, 'userId');

  try {
    logger.log(`Received userId: ${userId} - Event: ${JSON.stringify(event)}`);
    const invoices = await invoicesService.getInvoicesByUserId(userId);

    context.callbackWaitsForEmptyEventLoop = false; // Allow AWS Lambda to reuse the connection

    return createSuccessResponse(invoices);
  } catch (error) {
    logger.error('Error occurred', error.stack);
    return handleLambdaError(error);
  }
};
