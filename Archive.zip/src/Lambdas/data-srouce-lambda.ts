import { DataSource } from 'typeorm';
import { dbConfig } from '../database/db.config';

// @ts-expected-error: boop
export const AppDataSource = new DataSource({ dbConfig });
