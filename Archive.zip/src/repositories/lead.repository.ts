import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { Lead } from '../entities/lead.entity';

@Injectable()
export class LeadRepository {
  constructor(public dataSource dataSource: DataSource) {}

  async findByUserId(luid: number): Promise<Lead[]> {
    return this.dataSource
      .getRepository(Lead)
      .createQueryBuilder('lead')
      .where('lead.luid = :luid', { luid })
      .getMany();
  }
}
