// some-script.ts (standalone script)
import { AppDataSource } from '../Lambdas/data-srouce-lambda';

(async () => {
  try {
    await AppDataSource.initialize();

    // Use AppDataSource.manager to perform create, read, update, delete operations
    // E.g., const users = await AppDataSource.manager.find(User);

    console.log('Data Source has been initialized!');

    // Don't forget to close the connection when done
    await AppDataSource.destroy();
  } catch (error) {
    console.error('Error during Data Source initialization', error);
  }
})();
