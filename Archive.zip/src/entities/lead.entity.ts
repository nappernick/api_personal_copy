import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { User } from './user.entity';

@Entity()
export class Lead {
  @PrimaryGeneratedColumn()
  lid: number;

  @ManyToOne(() => User, (user) => user.leads)
  @Column({ nullable: true })
  luid: number;

  @Column({ nullable: true })
  lcid?: number;

  @Column({ type: 'timestamp', nullable: true })
  ladate?: Date;

  @Column({ nullable: true })
  lstatus?: string;

  @Column({ nullable: true })
  lstatus2?: string;

  @Column({ nullable: true })
  ltype?: string;

  @Column({ nullable: true })
  lservice?: string;

  @Column({ nullable: true })
  lstatusuid?: number;

  @Column({ nullable: true })
  lstatusreason?: string;

  @Column({ type: 'timestamp', nullable: true })
  lstatusdate?: Date;

  @Column({ type: 'timestamp', nullable: true })
  llastcontact?: Date;

  @Column({ nullable: true })
  llastcontactuid?: number;

  @Column({ nullable: true })
  lsource?: string;

  @Column({ nullable: true })
  lcomp?: string;

  @Column({ nullable: true })
  lcontact?: string;

  @Column({ nullable: true })
  ltitle?: string;

  @Column({ nullable: true })
  llname?: string;

  @Column({ nullable: true })
  laddr1?: string;

  @Column({ nullable: true })
  laddr2?: string;

  @Column({ nullable: true })
  lcity?: string;

  @Column({ nullable: true })
  lst?: string;

  @Column({ nullable: true })
  lzip?: number;

  @Column({ nullable: true })
  llatlon?: string;

  @Column({ nullable: true })
  lphone?: string;

  @Column({ nullable: true })
  lext?: string;

  @Column({ nullable: true })
  laltphone?: string;

  @Column({ nullable: true })
  laltext?: string;

  @Column({ nullable: true })
  lemail?: string;

  @Column({ nullable: true })
  llotid?: bigint;

  @Column({ nullable: true })
  lnotes?: string;

  @Column({ nullable: true })
  lfax?: string;

  @Column({ nullable: true })
  lcontact2?: string;

  @Column({ nullable: true })
  ltitle2?: string;

  @Column({ nullable: true })
  lphone2?: bigint;

  @Column({ nullable: true })
  lext2?: string;

  @Column({ nullable: true })
  lemail2?: string;

  @Column({ nullable: true })
  lemail2cc?: string;

  @Column({ nullable: true })
  lbtype?: string;

  @Column({ nullable: true })
  lbfloors?: number;

  @Column({ nullable: true })
  lbroofmat?: string;

  @Column({ nullable: true })
  lbhatch?: string;

  @Column({ nullable: true })
  lbheight?: number;

  @Column({ type: 'timestamp', nullable: true })
  linspection?: Date;

  @Column({ type: 'timestamp', nullable: true })
  linspectioncomp?: Date;

  @Column({ nullable: true })
  linspectionnotes?: string;

  @Column({ nullable: true })
  llocnotes?: string;

  @Column({ nullable: true })
  lapp?: number;

  @Column({ nullable: true })
  linvpays?: string;

  @Column({ nullable: true })
  linsuranceco?: string;

  @Column({ nullable: true })
  lclaimnum?: string;

  @Column({ nullable: true })
  lsimpleinspections?: string;

  @ManyToOne(() => User, (user) => user.leads)
  user: User;
}
