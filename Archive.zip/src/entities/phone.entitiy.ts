import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('PQ_photos')
export class Photo {
  @PrimaryGeneratedColumn()
  photoid: number;

  @Column()
  pjobid: number;

  @Column()
  pwoid: number;

  @Column()
  pwotype: string;

  @Column()
  puser: string;

  @Column()
  photoname: number;

  @Column()
  photoext: string;

  @Column({ type: 'timestamp' })
  photodts: Date;

  @Column()
  photolabel: string;

  @Column()
  phototags: string;

  @Column()
  photoorder: number;

  @Column()
  photoidcc: number;

  @Column({ type: 'timestamp' })
  photodtscc: Date;

  @Column()
  photoreq: string;

  @Column()
  photonotes: string;

  // Similar to the DTO, TypeORM decorators will be required for the rest of the properties
  // ... continue with rest of the properties

  // For the checklist and other relations, you need to define them properly using @OneToOne, @OneToMany or @ManyToOne etc.

  // Example for a OneToMany relation if PQ_photosChecklist is a collection type:
  // @OneToMany(() => PhotosChecklist, photosChecklist => photosChecklist.photo)
  // PQ_photosChecklist: PhotosChecklist[];

  // After defining the relations you will also need an entity for each related item,
  // so PhotosChecklist, PhotosChecklistIDX, ProdServe etc. should have their own entities defined.
}
import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('PQ_photos')
export class Photo {
  @PrimaryGeneratedColumn()
  photoid: number;

  @Column()
  pjobid: number;

  @Column()
  pwoid: number;

  @Column()
  pwotype: string;

  @Column()
  puser: string;

  @Column()
  photoname: number;

  @Column()
  photoext: string;

  @Column({ type: 'timestamp' })
  photodts: Date;

  @Column()
  photolabel: string;

  @Column()
  phototags: string;

  @Column()
  photoorder: number;

  @Column()
  photoidcc: number;

  @Column({ type: 'timestamp' })
  photodtscc: Date;

  @Column()
  photoreq: string;

  @Column()
  photonotes: string;

  // Similar to the DTO, TypeORM decorators will be required for the rest of the properties
  // ... continue with rest of the properties

  // For the checklist and other relations, you need to define them properly using @OneToOne, @OneToMany or @ManyToOne etc.

  // Example for a OneToMany relation if PQ_photosChecklist is a collection type:
  // @OneToMany(() => PhotosChecklist, photosChecklist => photosChecklist.photo)
  // PQ_photosChecklist: PhotosChecklist[];

  // After defining the relations you will also need an entity for each related item,
  // so PhotosChecklist, PhotosChecklistIDX, ProdServe etc. should have their own entities defined.
}
