https://docs.aws.amazon.com/whitepapers/latest/microservices-on-aws/microservices-on-aws.html
