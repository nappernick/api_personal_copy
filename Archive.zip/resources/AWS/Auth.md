https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-method-request-validation.html
https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-integrate-with-cognito.html
