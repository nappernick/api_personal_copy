https://docs.nestjs.com/first-steps
https://docs.nestjs.com/techniques/performance
https://tsh.io/blog/reduce-node-modules-for-better-performance/
https://github.com/tj/node-prune
