https://fastify.dev/docs/latest/
https://fastify.dev/docs/latest/Reference/TypeScript/
https://dev.to/itsrennyman/how-i-structure-my-fastify-application-1j93
https://medium.com/geekculture/deploy-fastify-app-to-aws-lambda-89cce91c1e4e
https://fastify.dev/docs/v3.29.x/Guides/Serverless/
https://fastify.dev/docs/v3.29.x/Reference/TypeScript/#typescript
https://www.jsonschemavalidator.net/
https://voice.google.com/u/2/messages?itemId=t.%2B18159311904
